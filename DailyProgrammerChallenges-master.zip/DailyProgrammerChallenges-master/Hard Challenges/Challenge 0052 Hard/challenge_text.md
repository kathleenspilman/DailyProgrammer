Your task is to write functions that encrypt and decrypt using the [solitaire cipher](http://www.schneier.com/solitaire.html). 

