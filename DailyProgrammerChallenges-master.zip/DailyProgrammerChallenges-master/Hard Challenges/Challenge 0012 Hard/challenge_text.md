Write a program which will take string inputs "A", "B", "C", "D", "E", "F", and "G", and make the corresponding notes, in any method of your choosing.

Thanks to electric_machinery for this challenge!