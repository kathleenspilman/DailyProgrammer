build a tic tac toe game with opponent AI

bonus points for cooler AI implementations (depth/breadth first search, neural network, etc)