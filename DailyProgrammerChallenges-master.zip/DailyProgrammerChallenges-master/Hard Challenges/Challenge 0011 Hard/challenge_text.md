Create a program which prints out a table with the month's calendar in it, when the month and year is given as input.

Extra points for highlighting the current day and providing links to next and previous months. 

Happy coding :) 