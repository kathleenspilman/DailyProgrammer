Write a program that draws a [square spiral](http://10binary.deviantart.com/art/square-spiral-203786602). You can print out this spiral in ASCII text, but using a graphics library would produce a more pleasant output.

Bonus: Now draw a normal spiral. Some samples of spirals can be found [here](http://images.google.com/search?tbm=isch&hl=en&source=hp&biw=1920&bih=987&q=spiral&gbv=2&oq=spiral&aq=f&aqi=g10&aql=&gs_sm=3&gs_upl=2312l3239l0l3992l6l6l0l1l1l0l104l429l4.1l5l0).
