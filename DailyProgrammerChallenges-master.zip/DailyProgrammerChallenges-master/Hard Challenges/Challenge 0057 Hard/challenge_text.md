Lets play some games shall we! .. for many of the next challenges i will be giving old classic games to be programmed. 

Today your task is to implement [Hamurabi](http://atariarchives.org/basicgames/showpage.php?page=78). the link gives data required in implementing. Enjoy! :)

________________________

Edit: [Here](http://pastebin.com/LvsZHGTd) is the basic code for making things easier.
