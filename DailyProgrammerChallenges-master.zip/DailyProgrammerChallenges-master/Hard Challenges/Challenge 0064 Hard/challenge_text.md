One of the sites where daily weather forecasts are shown is [here](http://weather.noaa.gov/pub/data/forecasts/.)

Get the forecast of any asked city and also try to be more innovative in your answers

_____________________________________________________

It seems the number of users giving challenges have been reduced. Since my final exams are going on and its kinda difficult to think of all the challenges, I kindly request you all to suggest us interesting challenges at /r/dailyprogrammer_ideas .. Thank you!