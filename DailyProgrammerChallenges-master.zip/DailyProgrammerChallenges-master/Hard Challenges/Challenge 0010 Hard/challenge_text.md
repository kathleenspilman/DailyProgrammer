Your task is to implement the interactive game of [hangman](http://en.wikipedia.org/wiki/Hangman_\(game\))

bonus point for making the game unique. be more creative!