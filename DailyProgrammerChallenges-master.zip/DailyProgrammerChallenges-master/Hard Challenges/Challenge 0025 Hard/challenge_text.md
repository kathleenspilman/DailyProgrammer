Write a program that places N queens on an NxN chessboard such that no two queens are on the same row, column, or diagonal, and no queen is on either of the two major diagonals (corner to corner). Get a solution for as large a value of N as you can.

* [Sample valid board for N = 8](http://pastebin.com/5JYt1XND)  
* [Sample valid board for N = 48](http://pastebin.com/nwgdf8rk)

thanks to Cosmologicon for today's challenge submitted at [/r/dailyprogrammer_ideas](/r/dailyprogrammer_ideas) 

