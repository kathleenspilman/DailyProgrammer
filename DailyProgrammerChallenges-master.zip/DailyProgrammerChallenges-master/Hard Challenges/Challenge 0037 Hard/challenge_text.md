Your task is to implement [Cornacchia�s algorithm](http://en.wikipedia.org/wiki/Cornacchia's_algorithm) and use it to demonstrate that all primes of the form 4k+1 and less than 1000 can be written as the sum of two squares.

source: [programmingpraxis.com](http://programmingpraxis.com/2012/04/03/cornacchias-algorithm/)

