The U.S government has commissioned you to catch the terrorists! 

There is a mathematical pyramid with the following pattern:

1

11

21

1211

111221

312211

you must write a program to calculate up to the 40th line of this pyramid. If you don't, the terrorists win!