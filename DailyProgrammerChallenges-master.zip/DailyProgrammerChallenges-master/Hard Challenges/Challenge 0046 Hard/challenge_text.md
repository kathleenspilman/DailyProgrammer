The prime HP reached starting from a number , concatenating its prime factors, and repeating until a prime is reached. If you have doubts, refer the article [here](http://mathworld.wolfram.com/HomePrime.html) 

write a function to calculate the HP of a given number. 

Also write a function to compute the [Euclid-Mullin sequence](http://mathworld.wolfram.com/Euclid-MullinSequence.html).

