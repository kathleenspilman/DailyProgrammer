create a program that will remind you to stop procrastinating every two hours with a pop up message! :)

This program has the potential of helping many people :D