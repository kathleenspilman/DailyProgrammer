Today's difficult problem is similar to challenge #64's difficult problem


Baseball is very famous in the USA. Your task is write a program that retrieves the current statistic for a requested team. [THIS](http://www.baseball-reference.com/) site is to be used for the reference. You are also encouraged to retrieve some more information from the site .. just use your creativity! :D

Bonus: Stock prices can be retrieved from [this site](http://finance.yahoo.com/) ... your task is to retrieve the current price of a requested company.  

