Write a program to implement the [Pollard's rho algorithm](http://en.wikipedia.org/wiki/Pollard's_rho_algorithm) using both, [Floyd�s cycle-finding algorithm](http://en.wikipedia.org/wiki/Cycle_detection) and [Brent�s cycle-finding algorithm](http://en.wikipedia.org/wiki/Cycle_detection#Brent.27s_algorithm) .. 

Bonus: also compare the timings for the implementation of both the algorithms and come up stating whichever is the fastest.

 


