create an AI that will play [NIM](http://en.wikipedia.org/wiki/Nim)
