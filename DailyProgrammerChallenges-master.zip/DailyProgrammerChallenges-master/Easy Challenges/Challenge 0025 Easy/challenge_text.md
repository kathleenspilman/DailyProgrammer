In an election, the person with the majority of the votes is the winner. Sometimes due to similar number of votes, there are no winners. 

Your challenge is to write a program that determines the winner of a vote, or shows that there are no winners due to a lack of majority.


