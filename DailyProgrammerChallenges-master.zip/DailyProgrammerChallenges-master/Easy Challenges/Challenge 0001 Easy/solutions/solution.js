function main() {
	var name = prompt("Hi, what is your name?");
	var age = prompt("Nice to meet you " + name + ", how old are you?");
	var username = prompt("Cool, what is your Reddit username?");

	alert("Your name is " + name + ", you are " + age + " years old, and your username is " + username + ".");
}

main();
