%Author: Evilk9 (github.com/evilk9)
name = input('What is your name? ', 's');
age = input('What is your age? '); 
username = input('What is your Reddit Username? ', 's');

fprintf('Your name is %s, you are %d years old, and your username is %s', name, age, username); 

