create a program that will find all prime numbers below 2000
