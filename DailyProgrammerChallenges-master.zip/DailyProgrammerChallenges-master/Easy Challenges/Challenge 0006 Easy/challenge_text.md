You're challenge for today is to create a program that can calculate pi accurately to at least 30 decimal places. 

Try not to cheat :)