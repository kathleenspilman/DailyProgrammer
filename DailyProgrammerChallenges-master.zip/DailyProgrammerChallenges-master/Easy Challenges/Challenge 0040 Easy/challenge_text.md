Print the numbers from 1 to 1000 without using any loop or conditional statements. 

Don�t just write the printf() or cout statement 1000 times.

Be creative and try to find the most efficient way!


_________________________

* source: stackexchange.com
