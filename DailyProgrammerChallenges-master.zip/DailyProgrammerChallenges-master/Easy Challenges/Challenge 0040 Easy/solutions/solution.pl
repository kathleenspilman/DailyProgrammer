#!/usr/bin/perl --

use v5.18;
use warnings;

$, = "\n";
say 1..1000;
