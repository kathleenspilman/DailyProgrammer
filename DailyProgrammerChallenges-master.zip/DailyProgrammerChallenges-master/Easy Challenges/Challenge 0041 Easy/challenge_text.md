Write a program that will accept a sentence as input and then output that sentence surrounded by some type of an ASCII decoratoin banner.

Sample run:



Enter a sentence:  So long and thanks for all the fish

Output

    *****************************************
    *                                       *
    *  So long and thanks for all the fish  *
    *                                       *
    *****************************************




Bonus:  If the sentence is too long, move words to the next line.