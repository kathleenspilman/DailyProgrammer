Give the [Ullman's Puzzle](http://regator.com/p/246306389/ullmans_puzzle/)

Write a function that makes that determination

