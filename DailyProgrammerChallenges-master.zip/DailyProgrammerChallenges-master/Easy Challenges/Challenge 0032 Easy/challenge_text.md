lets simulate a roulette wheel!  
a program that takes as input your bet, and gives as output how much you won, with the appropriate probability


write a program that will take a players bet and output the resulting spin and payout.
try using an american roulette wheel (which has the 00 slot) to add a slight twist. and try to incorporate as many complex bets as you can to. a comprehensive list can be found [here](http://en.wikipedia.org/wiki/Roulette#Bet_odds_table)

* thanks to SleepyTurtle for the challenge at [/r/dailyprogrammer_ideas](/r/dailyprogrammer_ideas) 
