~~Your task is to implement [Ackermann Function](http://en.wikipedia.org/wiki/Ackermann_function) in the most efficient way possible.~~

~~Please refer the wiki page link given for its explanation.~~

____________________________________________________

Since many did not like the previous challenge because it was quite unsatisfactory here is a new challenge ... 

Input: A sequence of integers either +ve or -ve 

Output : a part of the sequence in the list with the maximum sum. 

__________________________

**UPDATE:** I have given some more info on the [difficult] challenge since it seems to be very tough. you have upto monday to finish all these challenges. pls note it :)