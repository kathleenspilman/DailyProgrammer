[Emirp](http://mathworld.wolfram.com/Emirp.html) is an interesting concept. The explanation about it is provided in the link i just gave.

Your task is to implement a function which prints out the emirps below a number(input) given by the user.