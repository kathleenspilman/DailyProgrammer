Your challenge for today is to create a program which is password protected, and wont open unless the correct user and password is given. 

For extra credit, have the user and password in a seperate .txt file.

for even more extra credit, break into your own program :)