How many words contained in [this dictionary](http://code.google.com/p/dotnetperls-controls/downloads/detail?name=enable1.txt) have their letters in alphabetical order? So, for instance the letters in "ghost" and "bee" is in alphabetical order, but the letters in "cab" are not. 

***

* Thanks to [EvanHahn](http://www.reddit.com/user/EvanHahn) for suggesting this problem at /r/dailyprogrammer_ideas! 
