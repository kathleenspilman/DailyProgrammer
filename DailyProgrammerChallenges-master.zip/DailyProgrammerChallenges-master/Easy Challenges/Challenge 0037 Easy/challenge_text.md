write a program that takes

input :  a file as an argument

output: counts the total number of lines. 

for bonus, also count the number of words in the file. 
