puts File.readlines(ARGV[0]).length
