Write a program to solve the sliding window minimum problem using any of the methods possible. [This](http://home.tiac.net/~cri/2001/slidingmin.html) could be a helpful link. 

