Implement [Dijkstra's algorithm](http://en.wikipedia.org/wiki/Dijkstra's_algorithm) in any way you can :)

