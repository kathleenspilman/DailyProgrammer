Input: a number

Output : the next higher number that uses the same set of digits. 
