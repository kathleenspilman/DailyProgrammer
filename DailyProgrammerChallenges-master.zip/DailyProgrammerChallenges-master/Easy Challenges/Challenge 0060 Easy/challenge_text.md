A polite number n is an integer that is the sum of two or more consecutive nonnegative integers in at least one way.

[Here](http://en.wikipedia.org/wiki/Polite_number) is an article helping in understanding Polite numbers

Your challenge is to write a function to determine the ways if a number is polite or not.
