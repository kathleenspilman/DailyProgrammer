Write a program that will take a number and print a right triangle attempting to use all numbers from 1 to that number.



Sample Run:



Enter number:  10

Output:

7 8 9 10

4 5 6

2 3

1



Enter number:  6

Output:

4 5 6

2 3

1



Enter number:  3

Output:

2 3

1



Enter number:  12

Output:

7 8 9 10

4 5 6

2 3

1