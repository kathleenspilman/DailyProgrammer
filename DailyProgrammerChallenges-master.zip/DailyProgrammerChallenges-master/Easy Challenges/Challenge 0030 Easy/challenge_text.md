Write a program that takes a list of integers and a target number and determines if any two integers in the list sum to the target number. If so, return the two numbers. If not, return an indication that no such integers exist.

______________________________________________________________________________________________
Edit : Note the "Intermediate" challenge #30 has been changed. Thank you!