#Description:

As we enter a new year it is a good time to get organized and be ready. One thing I have noticed as you use this subreddit and finish challenges you repeat lots of code in solutions. This is true in the area of reading in data.

One thing I have done is develop some standard code I use in reading and  parsing data.

For today's challenge you will be doing some prep work for yourself. 

#Tool Development

Develop a tool or several tools you can use in the coming year for completing challenges. The tool is up to you. It can be anything that you find you repeat in  your code. 

An example will be shown below that I use. But some basic ideas

* Read input from user
* Input from a file
* Output to user
* Output to a file

Do not limit yourself to these. Look at your previous code and find the pieces of code you repeat a lot and develop your own library for handling that part of your challenges. Having this for your use will make solutions easier to develop as you already have that code done.

#Example:

I tend to do a lot of work in C/objective C -- so I have this code I use a lot for getting input from the user and parsing it. It can be further developed and added on by me which I will.

(https://github.com/coderd00d/standard-objects)

#Solutions:

Can be your code/link to your github/posting of it -- Also can just be ideas of tools you or others can develop.
